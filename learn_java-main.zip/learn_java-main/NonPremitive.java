public class NonPremitive {
    public static void main(String[] args) {
        String name = "Rahul";
        String friend = new String("akku");
        System.out.println(name);
        System.out.println(friend);
        System.out.println(name.length());
        System.out.println(friend.length());
    }
}