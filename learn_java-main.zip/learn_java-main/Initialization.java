public class Initialization {
    public static void main(String[] args) {
        int[] marks = new int[4];
        // marks[0] = 97;
        // marks[1] =99;
        boolean[] price = new boolean[4];
        // price[0] = true;
        // price[1] = false;
        System.out.println(marks[2]);
        System.out.println(price[3]);
    }
}