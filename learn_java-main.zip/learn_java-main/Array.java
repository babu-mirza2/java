public class Array {
    public static void main(String[] args) {
        int[] marks = new int[4];
        marks[0] = 98;
        marks[1] = 99;
        marks[2] = 100;
        marks[3] = 96;

        System.out.println(marks[0]);
        System.out.println(marks[1]);
        System.out.println(marks[2]);
        System.out.println(marks[3]);

    }

}
