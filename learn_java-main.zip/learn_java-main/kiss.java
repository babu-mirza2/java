class kiss{
    public static void main(string arg[]){
        system.out.println("i love you pakhi");
    } 
}