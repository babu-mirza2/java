public class Daffodil {
    public static void main(String[] args) {
        // int n = 5;
        String name = "Moni";
        String name1 = "Sunjid";
        String friend = name;
        System.out.println("Hello, " + name);
        System.out.println("My friend name is " + friend);
        // System.out.println(n);
        System.out.println(name1 + " loves " + name);
    }
}