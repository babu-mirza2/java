public class StringLength {
    public static void main(String[] args) {
        String name = "amin";
        System.out.println(name.length());
    }
}