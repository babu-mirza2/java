public class Test {
    public static void main(String[] args) {
        int i = 1234566784;
        byte age = 19;
        long phone = 123456789900000L;
        char email = 'a';
        float cgpa = 3.5f;
        boolean test = true;
        double salary = 123456789.123456789;

        System.out.println(i);
        System.out.println(age);
        System.out.println(phone);
        System.out.println(email);
        System.out.println(cgpa);
        System.out.println(test);
        System.out.println(salary);
        System.out.println("Mr. hamim is " + age + " years old & the cgpa is: " + cgpa);
    }
}