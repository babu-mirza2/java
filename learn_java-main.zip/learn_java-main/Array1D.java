import java.util.Array;

public class Array1D {
    public static void main(String[] args) {
        int[] marks = { 94, 99, 95, 100 };
        System.out.println(marks[0]);

    }
}
