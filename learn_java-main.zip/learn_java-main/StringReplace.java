public class StringReplace {
    public static void main(String[] args) {
        String name = "amin";
        String name2 = name.replace('n', 'r');
        System.out.println(name2);
    }
}