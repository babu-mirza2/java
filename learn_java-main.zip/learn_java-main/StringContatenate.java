public class StringContatenate {
    public static void main(String[] args) {
        String str1 = "Hello";
        String str2 = "World";
        String str4 = "I";
        String str5 = "You Moni";
        String str6 = str4 + " love " + str5;
        String str3 = str1 + " and " + str2;
        System.out.println(str3);
        System.out.println(str6);
    }
}