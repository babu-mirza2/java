public class Length {
    public static void main(String[] args) {
        int[] marks = new int[3];
        marks[0] = 98;
        marks[1] = 99;
        marks[2] = 96;
        System.out.println(marks.length);
    }
}