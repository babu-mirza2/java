//type casting
public class Type {
    public static void main(String args[]) {
        // Implicit casting
        double a = 100.78;
        double b = a + 19;
        System.out.println("Total: " + b + ";");
        // Explicit casting
        int c = 150;
        int d = (int) 19.6;
        int e = c + d;
        System.out.println("Total: " + e + ".");
    }
}