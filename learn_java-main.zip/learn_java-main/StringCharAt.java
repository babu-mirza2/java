public class StringCharAt {
    public static void main(String[] args) {
        String name = "Arman";
        System.out.println(name.charAt(1));
    }
}