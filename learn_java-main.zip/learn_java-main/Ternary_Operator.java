
//Ternary_Operator
import java.util.Scanner;

public class Ternary_Operator {
    public static void main(String args[]) {
        Scanner Input = new Scanner(System.in);

    }

}