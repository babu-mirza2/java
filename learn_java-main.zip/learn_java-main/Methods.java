//Methods
public class Methods {
    public static void printHello() {
        System.out.println("Hello Raju!");
    }

    public static void printString(String str) {
        System.out.println(str);
    }

    public static void printSum(int a, int b) {
        System.out.println(a + b);
    }

    public static void main(String args[]) {
        printHello();
        printString("Hello, World!");
        printSum(6, 9);
    }
}